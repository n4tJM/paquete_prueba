def sumar(a, b):
    return a + b