def mult(a, b):
    return a * b